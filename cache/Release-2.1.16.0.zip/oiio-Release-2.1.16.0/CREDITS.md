This is a list of all the contributors to OpenImageIO, sorted alphabetically
by first name.

If you know of somebody that I missed or have corrections, please email:
lg@openimageio.org

* Akihiro Yamasaki
* Alan Jones
* Alejandro Conty
* Alex Hughes
* Alex Schworer
* Alexander Kuleshov
* Alexander Murashko
* Alexandre Gauthier
* Alexis Oblet
* Alexy Pawlow
* Aman Shah
* Ananth Garre
* Arkady Shapkin
* Basileios Anastasatos
* Bastien Montagne
* Ben De Luca
* Blair Tennessy
* Brecht Van Lommel
* Brent Davis
* Brian Hall
* Carl Rand
* Cassian Andrei
* Chad Dombrova
* Changlin Hsieh
* Chris Foster
* Chris Kulla
* Christoph Willing
* Cliff Stein
* Clément Champetier
* Dan Wexler
* Daniel Dresser
* Daniel Flehner Heen
* Daniel Wyatt
* David Aguilar
* David Gordon
* Deepak Gopinath
* Delai Felinto
* Dennis Schridde
* Dinko Galetik
* Dominik Bartkiewicz
* Duncan Chan
* Edgar Velazquez-Armendariz
* Eloi Du Bois
* Elvic Liang
* Fabien Castan
* Fabien Servant
* Frédéric Devernay
* Fredrik Averpil
* Ghislain Antony Vaillant
* Gonzalo Garramuño
* Grégoire De Lillo
* Gregor Mueckl
* Guillaume Chatelet
* Hanspeter Niederstrasser
* Heiko Becker
* Henri Fousse
* Harry Mallon
* Hugh Macdonald
* Irena Damsky
* Ismael Cortes
* Jep Hill
* Jeph Alapat
* Jeremy Rose
* Jeremy Selan
* Jim Hourihan
* John Burnett
* John Haddon
* Jonathan Scruggs
* Joseph Goldstone
* Julien Enche
* Justin Israel
* Justina Mikonyte
* Kazuki Takahashi
* Kevin Brightwell
* Konrad Kleine
* Krzysztof Blicharski
* Larry Gritz (project leader)
* LazyDodo
* Leonid Onokhov
* Leszek Godlewski
* Lucas Panian
* Lucille Caillaud
* Lukas Schrangl
* Lukasz Maliszewski
* M Joonas Pihlaja
* Malcolm Humphreys
* Manuel Gamito
* Manuel Leonhardt
* Marcos Fajardo
* Marie Fetiveau
* Mariusz Szczepanczyk
* Mark Boorer
* Mark Visser
* Matteo F. Vescovi
* Matthew E. Levine
* Max Liani
* Michel Lerenard
* Michel Normand
* Mikael Sundell
* Mike Root
* Morteza Ramezanali
* Nandan Dubey
* Nathan Rusch
* Nicholas Yue
* Nick Black
* Nicolas Burtnyk
* Nixon Kwok
* Nuno Cardoso
* Ott Tinn
* Pascal Lecocq
* Patrick Hodoul
* Paul Molodowitch
* Pavel Karneliuk
* Pete Larabell
* Philip Nemec
* Pino Toscano
* Puneet Jain
* Ramon Montoya
* Ray Molenkamp
* Richard Shaw
* Roeland Schoukens
* Robert Matusewicz
* Roman Zulak
* Rui Li
* Ryen
* Saket Jalan
* Sam Richards
* Samuel Nicholas
* Scott Wilson
* Sebastian Elsner
* Seifeddine Dridi
* Sergey Sharybin
* Shane Ambler
* Simon Boorer
* Solomon Boulos
* Stefan Bruens
* Stefan Stavrev
* Thiago Ize
* Thomas Dinges
* Thomas Mansencal
* Till Dechent
* Tim D. Smith
* Tim Grant
* Troy James Sobotka
* Vinod Khare
* Vishal Agrawal
* Vitor Franchi
* Will Rosecrans
* Wormszer
* Xo Wang
* Yang Yang
* Yann Lanthony
