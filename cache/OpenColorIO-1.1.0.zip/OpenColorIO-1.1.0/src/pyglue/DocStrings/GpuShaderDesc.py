
class GpuShaderDesc:
    """
    GpuShaderDesc
    """
    def __init__(self):
        pass
    def setLanguage(self, lang):
        pass
    def getLanguage(self):
        pass
    def setFunctionName(self, name):
        pass
    def getFunctionName(self):
        pass
    def setLut3DEdgeLen(self, len):
        pass
    def getLut3DEdgeLen(self):
        pass
    def getCacheID(self):
        pass

