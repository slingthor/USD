Issues
======

Please visit http://github.com/imageworks/OpenColorIO/issues for an up to date
listing of bugs, feature requests etc
