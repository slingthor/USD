Python Types
============

Constants
*********

.. automodule:: PyOpenColorIO.Constants
    :members:
    :undoc-members:
