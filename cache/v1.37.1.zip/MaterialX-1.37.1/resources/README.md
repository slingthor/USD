# Resources

- [Geometry](Geometry): Sample geometry files. Includes files used by test suite.
- [Images](Images): Sample image files. Includes files used by test suite.
- [Materials](Materials) : Set of MaterialX documents. Includes [test suite files](Materials/TestSuite).
