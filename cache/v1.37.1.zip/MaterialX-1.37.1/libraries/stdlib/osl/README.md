# OSL Reference Implementations

This folder contains reference OSL implementations for the standard MaterialX nodes, documenting their intended functionality as of MaterialX v1.35.

The Open Shading Language team maintains source file generators for the MaterialX nodes at https://github.com/imageworks/OpenShadingLanguage/tree/master/src/shaders/MaterialX, and these source files were built from [this version](https://github.com/imageworks/OpenShadingLanguage/tree/e9e55306ea7b4356b51c91c180e6e9ac1cad6bb1) of the repository.
