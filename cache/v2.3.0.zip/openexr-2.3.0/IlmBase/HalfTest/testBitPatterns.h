
void testBitPatterns ();

