// DEPRECATED header OpenImageIO/version.h
// For back compatibility, just include the new name, oiioversion.h.

#include "oiioversion.h"
