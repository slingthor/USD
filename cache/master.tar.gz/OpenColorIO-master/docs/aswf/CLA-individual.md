<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenColorIO Project. -->

Individual Contributor License Agreement ("Agreement")

Thank you for your interest in the OpenColorIO Project a Series of LF
Projects, LLC (hereinafter "Project"). In order to clarify the
intellectual property licenses granted with Contributions from any
corporate entity to the Project, LF Projects, LLC ("LF Projects") is
required to have an Individual Contributor License Agreement (ICLA) on
file that has been signed by each contributing individual. (For legal
entities, please use the Corporate Contributor License Agreement
(CCLA).)

Each contributing individual ("You") must accept and agree that, for
any Contribution (as defined below), You are bound by the licenses
granted and representations made herein.

"Contribution" means any code, documentation or other original work of
authorship that is submitted to LF Projects for inclusion in the
Project by You or by another person authorized to make the submission
on Your behalf.

You accept and agree that all of Your present and future Contributions
to the Project shall be:

Submitted under a Developer's Certificate of Origin v. 1.1 (DCO); and
Licensed under the BSD-3-Clause License.



Signature: __________________________________________


Name: _______________________________________________


Date: _______________________________________________
