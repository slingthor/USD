..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

Issues
======

Please visit http://github.com/AcademySoftwareFoundation/OpenColorIO/issues for an up to date
listing of bugs, feature requests etc
