# SPDX-License-Identifier: BSD-3-Clause
# Copyright Contributors to the OpenColorIO Project.

class MatrixTransform:
    """
    MatrixTransfom
    """
    def __init__(self):
        pass
    def equals(self, matrix):
        pass
    def getValue(self):
        pass
    def setValue(self, value):
        pass
    def getMatrix(self):
        pass
    def setMatrix(self, matrix):
        pass
    def getOffset(self):
        pass
    def setOffset(self, offset):
        pass
    def Identity(self):
        pass
    def Fit(self):
        pass
    def Sat(self):
        pass
    def Scale(self):
        pass
    def View(self):
        pass
