# SPDX-License-Identifier: BSD-3-Clause
# Copyright Contributors to the OpenColorIO Project.

class GroupTransform:
    """
    GroupTransform
    """
    def __init__(self):
        pass
    def getTransform(self):
        pass
    def getTransforms(self):
        pass
    def setTransforms(self, transforms):
        pass
    def size(self):
        pass
    def push_back(self, transform):
        pass
    def clear(self):
        pass
    def empty(self):
        pass
