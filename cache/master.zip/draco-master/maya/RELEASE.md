# Next Features
* Add Support for Mesh Vertex Color attribute
* Add possibility to tweak Draco Export settings from Maya
* Include binaries for Mac OS
* Include binaries for Linux

# Relase v0.0.1
* Support .drc format: TRIANGULAR MESH  (no POINT CLOUD)
* Import .drc file into Maya by "Import menu" and "Drag & Drop"
* Export from Maya into .drc file by "Export Selection menu"
* Export is done using default draco settings
* Handling Mesh made of Tringular Meshes
* Mesh attributes supported: Vertices, Normals and Uvs
* Plugin built for Windows x64

