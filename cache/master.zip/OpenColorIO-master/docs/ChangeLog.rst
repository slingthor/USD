..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _changelog-main:

ChangeLog
=========

.. include:: CHANGELOG.md
