..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

Python Types
============

Constants
*********

.. automodule:: PyOpenColorIO.Constants
    :members:
    :undoc-members:
