All data under files/ covered by:

SPDX-License-Identifier: BSD-3-Clause
Copyright Contributors to the OpenColorIO Project.
