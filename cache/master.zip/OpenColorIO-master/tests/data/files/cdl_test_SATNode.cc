<ColorCorrection id="foo">
  <SOPNode>
    <Description>this is a description</Description>
    <Slope>1.1 1.2 1.3</Slope>
    <Offset>2.1 2.2 2.3</Offset>
    <Power>3.1 3.2 3.3</Power>
  </SOPNode>
  <SATNode>
    <Saturation>0.42</Saturation>
  </SATNode>
</ColorCorrection>