<ColorCorrection id="cc0001">
		<SOPNode>
				<Description>Example look</Description>
				<Slope>1.0 1.0 0.9</Slope>
				<Offset>-.03 -2e-2 0</Offset>
				<Power>1.25 1 1e0</Power>
		</SOPNode>
		<SatNode>
				<Description>boosting sat</Description>
				<Saturation>1.700000</Saturation>
		</SatNode>
</ColorCorrection>
