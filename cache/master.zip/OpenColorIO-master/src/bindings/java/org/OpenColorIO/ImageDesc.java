// SPDX-License-Identifier: BSD-3-Clause
// Copyright Contributors to the OpenColorIO Project.

package org.OpenColorIO;
import org.OpenColorIO.*;

public class ImageDesc extends LoadLibrary
{
    public ImageDesc() { super(); }
    protected ImageDesc(long impl) { super(impl); }
};
