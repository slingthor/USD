# SPDX-License-Identifier: BSD-3-Clause
# Copyright Contributors to the OpenColorIO Project.

class GpuShaderDesc:
    """
    GpuShaderDesc
    """
    def __init__(self):
        pass
    def setLanguage(self, lang):
        pass
    def getLanguage(self):
        pass
    def setFunctionName(self, name):
        pass
    def getFunctionName(self):
        pass
    def getCacheID(self):
        pass
    def finalize(self):
        pass

